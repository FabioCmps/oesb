You can use this folder in case of you need or you want to extend component's 
classloader.

For example, if you want to add a JMS provider for JBossMQ or IMQ, you can add
their respective libraries into libext/sun-jms-binding/
